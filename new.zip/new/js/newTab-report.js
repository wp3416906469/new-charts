// Report
window.customReportHref = 'https://plugin.csdn.net/packages/newTab/index.html';
