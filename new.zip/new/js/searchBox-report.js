// Report
window.customReportHref = 'https://plugin.csdn.net/packages/search-box/index.html';
